﻿import type { TransferDragPayload } from '../../api/types';
import { useI18n } from '../../i18n';
import { useAuthStore } from '../../store/auth';
import type { CenterPanelMode, RemotePaneState } from '../../store/workspace';
import { LocalPanel } from '../file-browser/LocalPanel';
import { RemotePane } from '../remote-workspace/RemotePane';

interface MiddleWorkspaceProps {
  panes: RemotePaneState[];
  mode: CenterPanelMode;
  centerSessionId: string | null;
  onChangeMode: (mode: CenterPanelMode) => void;
  onQueueLocalDownloads: (payload: TransferDragPayload, targetDir: string) => void | Promise<void>;
  onCloseSession: (sessionId: string) => void;
  onQueueUploads: (localPaths: string[], sessionId: string, targetDir: string) => void | Promise<void>;
  onQueueDownloads: (sessionId: string, remotePaths: string[], targetDir: string) => void | Promise<void>;
  onQueueRemoteCopies: (
    srcSessionId: string,
    dstSessionId: string,
    remotePaths: string[],
    targetDir: string,
  ) => void | Promise<void>;
}

export function MiddleWorkspace({
  panes,
  mode,
  centerSessionId,
  onChangeMode,
  onQueueLocalDownloads,
  onCloseSession,
  onQueueUploads,
  onQueueDownloads,
  onQueueRemoteCopies,
}: MiddleWorkspaceProps) {
  const { t } = useI18n();
  const health = useAuthStore((state) => state.health);
  const localLabel = health?.runtime_mode === 'local-dev' ? t('endpoint.local') : t('endpoint.workspace');
  const canUseRemote = panes.length > 0;
  const effectiveMode = mode === 'remote' && canUseRemote ? 'remote' : 'local';
  const centerPane = panes.find((pane) => pane.sessionId === centerSessionId) ?? panes[0] ?? null;

  return (
    <section className="middle-workspace">
      <div className="panel-shell middle-panel-switch">
        <div className="middle-panel-switch-row">
          <div className="middle-panel-switch-copy">
            <strong>{t('workspace.middlePanelMode')}</strong>
            <p>{t('workspace.middlePanelDescription')}</p>
          </div>
          <div className="middle-panel-toggle" role="group" aria-label={t('workspace.middlePanelMode')}>
            <button
              type="button"
              className={`middle-panel-button ${effectiveMode === 'local' ? 'is-active' : ''}`}
              onClick={() => onChangeMode('local')}
            >
              {localLabel}
            </button>
            <button
              type="button"
              className={`middle-panel-button ${effectiveMode === 'remote' ? 'is-active' : ''}`}
              onClick={() => onChangeMode('remote')}
              disabled={!canUseRemote}
            >
              {t('endpoint.remote')}
            </button>
          </div>
        </div>
      </div>

      {effectiveMode === 'local' ? (
        <LocalPanel onQueueDownloads={onQueueLocalDownloads} />
      ) : centerPane ? (
        <RemotePane
          pane={centerPane}
          onCloseSession={onCloseSession}
          onQueueUploads={onQueueUploads}
          onQueueDownloads={onQueueDownloads}
          onQueueRemoteCopies={onQueueRemoteCopies}
        />
      ) : (
        <section className="panel-shell remote-workspace-empty">
          <div className="placeholder-body">
            <strong>{t('workspace.middleRemoteEmptyTitle')}</strong>
            <p>{t('workspace.middleRemoteEmptyBody')}</p>
          </div>
        </section>
      )}
    </section>
  );
}
