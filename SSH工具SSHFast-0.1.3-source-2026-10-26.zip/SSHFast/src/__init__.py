"""SSHFast - SSH/SFTP GUI file management and transfer tool."""

__version__ = "0.1.3"
