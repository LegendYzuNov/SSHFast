"""App module initialization."""
