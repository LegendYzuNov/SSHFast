"""Core module initialization."""
