"""SFTP engine for file operations using Paramiko."""
import builtins
import logging
import os
import shlex
import socket
import stat
import time
from pathlib import Path
from typing import Callable, Optional

import paramiko
from paramiko import SFTPClient, SSHClient

from src.shared.errors import (
    AuthenticationError,
    ErrorCode,
    NetworkError,
    PathNotFoundError,
    SSHFastError,
)
from src.shared.errors import PermissionError as SFPermissionError
from src.shared.host_keys import fingerprint, install_policy
from src.shared.models import RemoteEntry, SiteConfig
from src.shared.paths import ensure_in_sandbox, normalize_remote_path, to_local_fs_path

DEFAULT_STREAM_CHUNK_BYTES = 4 * 1024 * 1024  # 4 MB
# SSH channel receive window. Paramiko's 2 MB default caps throughput at
# window/RTT (~160 Mbps at 100 ms); 16 MB keeps high-latency links saturated.
DEFAULT_SFTP_WINDOW_BYTES = 16 * 1024 * 1024


def _sftp_window_bytes() -> int:
    raw = os.getenv("SSHFAST_SFTP_WINDOW_BYTES", "")
    try:
        value = int(raw) if raw else DEFAULT_SFTP_WINDOW_BYTES
    except ValueError:
        return DEFAULT_SFTP_WINDOW_BYTES
    return max(64 * 1024, value)


def known_hosts_hint() -> str:
    """Best-effort path string for the managed known_hosts file (for messages)."""
    try:
        from src.shared.host_keys import known_hosts_path

        return str(known_hosts_path())
    except Exception:
        return "the SSHFast known_hosts file"


def _parse_proxy_jump(spec: str, *, default_user: str) -> tuple[str, str, int]:
    """Parse a ProxyJump spec ``[user@]host[:port]`` into (user, host, port)."""
    user = default_user
    host_part = spec
    if "@" in host_part:
        user, host_part = host_part.split("@", 1)
    port = 22
    # Bracketed IPv6 form: [::1]:2222
    if host_part.startswith("[") and "]" in host_part:
        host, _, tail = host_part[1:].partition("]")
        if tail.startswith(":") and tail[1:]:
            port = int(tail[1:])
    elif host_part.count(":") == 1:
        host, _, port_text = host_part.partition(":")
        if port_text:
            port = int(port_text)
    else:
        host = host_part
    return user or default_user, host, port


class SftpEngine:
    """
    SFTP engine for file management and transfer operations.
    
    Each instance maintains its own SSH/SFTP connection.
    Thread-safe when each thread uses its own instance.
    """

    def __init__(self, site_config: SiteConfig, logger: Optional[logging.Logger] = None):
        """
        Initialize SFTP engine.
        
        Args:
            site_config: Site configuration
            logger: Optional logger instance
        """
        self.site_config = site_config
        self.logger = logger or logging.getLogger(__name__)
        self.ssh_client: Optional[SSHClient] = None
        self.sftp_client: Optional[SFTPClient] = None
        self._proxy_client: Optional[SSHClient] = None
        self._connected = False
        self._ever_connected = False

    def connect(self) -> None:
        """
        Establish SSH and SFTP connections.
        
        Raises:
            AuthenticationError: If authentication fails
            NetworkError: If connection fails
            SSHFastError: For other connection issues
        """
        connect_kwargs = {
            "hostname": self.site_config.host,
            "port": self.site_config.port,
            "username": self.site_config.username,
            "timeout": 10,
            "banner_timeout": 20,
            "auth_timeout": 20,
            # Fall back to ssh-agent and default ~/.ssh keys when no explicit
            # key file is configured, matching what OpenSSH users expect.
            "allow_agent": True,
            "look_for_keys": True,
        }
        connect_kwargs["timeout"] = max(
            1,
            int(os.getenv("SSHFAST_CONNECT_TIMEOUT_SECONDS", str(connect_kwargs["timeout"])) or connect_kwargs["timeout"]),
        )
        connect_kwargs["banner_timeout"] = max(
            1,
            int(os.getenv("SSHFAST_BANNER_TIMEOUT_SECONDS", str(connect_kwargs["banner_timeout"])) or connect_kwargs["banner_timeout"]),
        )
        connect_kwargs["auth_timeout"] = max(
            1,
            int(os.getenv("SSHFAST_AUTH_TIMEOUT_SECONDS", str(connect_kwargs["auth_timeout"])) or connect_kwargs["auth_timeout"]),
        )

        if self.site_config.auth_method == "password":
            connect_kwargs["password"] = self.site_config.password
        elif self.site_config.auth_method == "key":
            if self.site_config.key_path:
                connect_kwargs["key_filename"] = self.site_config.key_path
            if self.site_config.key_passphrase:
                connect_kwargs["passphrase"] = self.site_config.key_passphrase

        attempts = max(1, int(os.getenv("SSHFAST_CONNECT_ATTEMPTS", "2") or "2"))
        retry_delay_seconds = max(0.2, float(os.getenv("SSHFAST_CONNECT_RETRY_DELAY_SECONDS", "1.0") or "1.0"))
        last_error: Exception | None = None

        for attempt in range(1, attempts + 1):
            self.disconnect()
            try:
                self.ssh_client = paramiko.SSHClient()
                install_policy(self.ssh_client)

                proxy_sock = self._open_proxy_channel()
                if proxy_sock is not None:
                    connect_kwargs["sock"] = proxy_sock
                else:
                    connect_kwargs.pop("sock", None)

                self.ssh_client.connect(**connect_kwargs)
                self.sftp_client = self._open_sftp_client()
                self._connected = True
                self._ever_connected = True
                self.logger.info(
                    f"Connected to {self.site_config.host}:{self.site_config.port}"
                )
                return
            except paramiko.BadHostKeyException as e:
                # The server's key changed since it was first trusted — treat
                # this as a hard security failure, never retry.
                self.disconnect()
                raise SSHFastError(
                    ErrorCode.HOSTKEY_CHANGED,
                    f"Host key verification failed for {self.site_config.host}:{self.site_config.port}. "
                    f"The server key changed and may indicate a man-in-the-middle attack. "
                    f"Expected {fingerprint(e.expected_key)}, got {fingerprint(e.key)}. "
                    f"If this change is expected, remove the host from {known_hosts_hint()}.",
                )
            except paramiko.AuthenticationException as e:
                self.disconnect()
                raise AuthenticationError(f"Authentication failed: {e}")
            except (paramiko.SSHException, socket.timeout, TimeoutError, OSError) as e:
                self.disconnect()
                error_text = str(e)
                if "not found in known_hosts" in error_text:
                    # Strict mode and the host was never trusted; retrying is
                    # pointless and the cause is a trust decision, not a network
                    # blip.
                    raise SSHFastError(
                        ErrorCode.HOSTKEY_UNKNOWN,
                        f"Host {self.site_config.host}:{self.site_config.port} is not in known_hosts "
                        f"and strict host key checking is enabled. Connect once with strict mode off "
                        f"to record its key, or add it to {known_hosts_hint()}.",
                    )
                last_error = e
                is_banner_error = "Error reading SSH protocol banner" in error_text
                if attempt < attempts:
                    current_delay = retry_delay_seconds * (2 if is_banner_error else 1)
                    self.logger.warning(
                        "SSH connect attempt %s/%s failed for %s:%s: %s%s; retrying in %.1fs",
                        attempt,
                        attempts,
                        self.site_config.host,
                        self.site_config.port,
                        e,
                        " [banner]" if is_banner_error else "",
                        current_delay,
                    )
                    time.sleep(current_delay)
                    retry_delay_seconds *= 2
                    continue
                raise NetworkError(ErrorCode.REMOTE_DISCONNECT, f"SSH error: {e}")
            except Exception as e:
                self.disconnect()
                raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Connection failed: {e}")

        if last_error is not None:
            raise NetworkError(ErrorCode.REMOTE_DISCONNECT, f"SSH error: {last_error}")

    def _open_proxy_channel(self):
        """Open a direct-tcpip channel through a ProxyJump host, if configured.

        Returns a paramiko Channel usable as the ``sock`` for the target
        connection, or ``None`` when no jump host is set. The jump host reuses
        the site's key/agent credentials (the common single-key setup).
        """
        proxy_spec = (self.site_config.proxy_jump or "").strip()
        if not proxy_spec:
            return None

        proxy_user, proxy_host, proxy_port = _parse_proxy_jump(
            proxy_spec, default_user=self.site_config.username
        )
        proxy_kwargs = {
            "hostname": proxy_host,
            "port": proxy_port,
            "username": proxy_user,
            "timeout": 10,
            "allow_agent": True,
            "look_for_keys": True,
        }
        if self.site_config.auth_method == "password":
            proxy_kwargs["password"] = self.site_config.password
        elif self.site_config.auth_method == "key":
            if self.site_config.key_path:
                proxy_kwargs["key_filename"] = self.site_config.key_path
            if self.site_config.key_passphrase:
                proxy_kwargs["passphrase"] = self.site_config.key_passphrase

        self._proxy_client = paramiko.SSHClient()
        install_policy(self._proxy_client)
        self._proxy_client.connect(**proxy_kwargs)
        transport = self._proxy_client.get_transport()
        if transport is None:
            raise SSHFastError(ErrorCode.REMOTE_DISCONNECT, "Jump host transport unavailable")
        return transport.open_channel(
            "direct-tcpip",
            (self.site_config.host, self.site_config.port),
            ("", 0),
        )

    def _open_sftp_client(self) -> SFTPClient:
        """Open the SFTP channel with an enlarged receive window when possible."""
        try:
            transport = self.ssh_client.get_transport()
            if transport is not None:
                return SFTPClient.from_transport(
                    transport,
                    window_size=_sftp_window_bytes(),
                )
        except Exception as e:
            self.logger.debug(f"Falling back to default SFTP channel: {e}")
        return self.ssh_client.open_sftp()

    def disconnect(self) -> None:
        """Close SSH and SFTP connections."""
        had_connection = self._connected or self.sftp_client is not None or self.ssh_client is not None
        if self.sftp_client:
            self.sftp_client.close()
            self.sftp_client = None
        if self.ssh_client:
            self.ssh_client.close()
            self.ssh_client = None
        if self._proxy_client:
            self._proxy_client.close()
            self._proxy_client = None
        self._connected = False
        if had_connection and self._ever_connected:
            self.logger.info("Disconnected from server")

    def is_connected(self) -> bool:
        """Check if connected."""
        return self._connected and self.ssh_client is not None

    def list_dir(self, remote_path: str) -> list[RemoteEntry]:
        """
        List directory contents.
        
        Args:
            remote_path: Remote directory path
            
        Returns:
            List of RemoteEntry objects
            
        Raises:
            PathNotFoundError: If path doesn't exist
            PermissionError: If permission denied
        """
        if not self.is_connected():
            raise SSHFastError(ErrorCode.REMOTE_DISCONNECT, "Not connected")

        # Sandbox check
        ensure_in_sandbox(remote_path, self.site_config.remote_root)
        normalized_path = normalize_remote_path(remote_path)

        try:
            entries = []
            for attr in self.sftp_client.listdir_attr(normalized_path):
                entry_path = f"{normalized_path}/{attr.filename}".replace('//', '/')
                entry_mode = attr.st_mode or 0
                entry = RemoteEntry(
                    name=attr.filename,
                    path=entry_path,
                    is_dir=stat.S_ISDIR(entry_mode),
                    size=attr.st_size or 0,
                    mtime=attr.st_mtime or 0,
                    mode=attr.st_mode,
                )
                entries.append(entry)

            return entries

        except FileNotFoundError:
            raise PathNotFoundError(f"Path not found: {remote_path}")
        except builtins.PermissionError:
            raise SFPermissionError(f"Permission denied: {remote_path}")
        except Exception as e:
            raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Failed to list directory: {e}")

    def mkdir(self, remote_path: str) -> None:
        """
        Create remote directory.
        
        Args:
            remote_path: Remote directory path to create
        """
        if not self.is_connected():
            raise SSHFastError(ErrorCode.REMOTE_DISCONNECT, "Not connected")

        ensure_in_sandbox(remote_path, self.site_config.remote_root)
        normalized_path = normalize_remote_path(remote_path)

        try:
            self.sftp_client.mkdir(normalized_path)
            self.logger.info(f"Created directory: {normalized_path}")
        except Exception as e:
            raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Failed to create directory: {e}")

    def remove_file(self, remote_path: str) -> None:
        """
        Remove remote file.
        
        Args:
            remote_path: Remote file path to remove
        """
        if not self.is_connected():
            raise SSHFastError(ErrorCode.REMOTE_DISCONNECT, "Not connected")

        ensure_in_sandbox(remote_path, self.site_config.remote_root)
        normalized_path = normalize_remote_path(remote_path)

        try:
            self.sftp_client.remove(normalized_path)
            self.logger.info(f"Removed file: {normalized_path}")
        except Exception as e:
            raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Failed to remove file: {e}")

    def remove_dir(self, remote_path: str) -> None:
        """
        Remove remote directory (must be empty).
        
        Args:
            remote_path: Remote directory path to remove
        """
        if not self.is_connected():
            raise SSHFastError(ErrorCode.REMOTE_DISCONNECT, "Not connected")

        ensure_in_sandbox(remote_path, self.site_config.remote_root)
        normalized_path = normalize_remote_path(remote_path)

        try:
            self.sftp_client.rmdir(normalized_path)
            self.logger.info(f"Removed directory: {normalized_path}")
        except Exception as e:
            raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Failed to remove directory: {e}")

    def remove_dir_recursive(self, remote_path: str) -> None:
        """
        Recursively remove remote directory using 'rm -rf'.
        
        Args:
            remote_path: Remote directory path to remove
        """
        if not self.is_connected():
            raise SSHFastError(ErrorCode.REMOTE_DISCONNECT, "Not connected")

        ensure_in_sandbox(remote_path, self.site_config.remote_root)
        normalized_path = normalize_remote_path(remote_path)

        # Safety check: ensure we are not deleting root or something obviously wrong
        if normalized_path == "/" or normalized_path == self.site_config.remote_root:
             raise SSHFastError(ErrorCode.UNKNOWN_ERROR, "Cannot delete root or sandbox root recursively")

        try:
            # Use SSH command for recursive delete
            # Shell-escape path to avoid command injection via crafted remote names.
            cmd = f"rm -rf -- {shlex.quote(normalized_path)}"
            stdin, stdout, stderr = self.ssh_client.exec_command(cmd)
            exit_status = stdout.channel.recv_exit_status()
            
            if exit_status != 0:
                err = stderr.read().decode().strip()
                raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Recursive delete failed: {err}")
                
            self.logger.info(f"Recursively removed directory: {normalized_path}")
        except SSHFastError:
            raise
        except Exception as e:
            raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Failed to recursive remove: {e}")

    def rename(self, old_path: str, new_path: str) -> None:
        """
        Rename/move remote file or directory.
        
        Args:
            old_path: Current path
            new_path: New path
        """
        if not self.is_connected():
            raise SSHFastError(ErrorCode.REMOTE_DISCONNECT, "Not connected")

        ensure_in_sandbox(old_path, self.site_config.remote_root)
        ensure_in_sandbox(new_path, self.site_config.remote_root)

        old_normalized = normalize_remote_path(old_path)
        new_normalized = normalize_remote_path(new_path)

        try:
            self.sftp_client.rename(old_normalized, new_normalized)
            self.logger.info(f"Renamed {old_normalized} -> {new_normalized}")
        except Exception as e:
            raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Failed to rename: {e}")

    def upload_file(
        self,
        local_path: str,
        remote_path: str,
        callback: Optional[Callable] = None,
        check_interrupt: Optional[Callable] = None,
        offset: int = 0
    ) -> None:
        """
        Upload a file to remote server with interrupt support.
        
        Args:
            local_path: Local file path
            remote_path: Remote destination path
            callback: Optional progress callback(bytes_transferred, bytes_total)
            check_interrupt: Optional function that returns True if transfer should stop
            offset: Byte offset to resume upload from
        """
        if not self.is_connected():
            raise SSHFastError(ErrorCode.REMOTE_DISCONNECT, "Not connected")

        ensure_in_sandbox(remote_path, self.site_config.remote_root)
        normalized_path = normalize_remote_path(remote_path)

        try:
            fs_local_path = to_local_fs_path(local_path)
            file_size = os.path.getsize(fs_local_path)
            chunk_size = DEFAULT_STREAM_CHUNK_BYTES
            
            # Determine mode based on offset
            mode = 'wb'
            if offset > 0:
                mode = 'ab'
                
            bytes_transferred = offset
            
            with open(fs_local_path, 'rb') as local_file:
                if offset > 0:
                    local_file.seek(offset)
                    
                with self.sftp_client.open(normalized_path, mode) as remote_file:
                    if hasattr(remote_file, "set_pipelined"):
                        remote_file.set_pipelined(True)
                    if offset > 0 and mode == 'wb':
                        # Should not happen if logic is correct, but 'ab' implies append.
                        # Some SFTP servers might not support 'ab' correctly without seek?
                        # Paramiko's open('ab') usually handles it.
                        remote_file.seek(offset)
                        
                    while True:
                        # Check for interruption
                        if check_interrupt and check_interrupt():
                            raise InterruptedError("Transfer interrupted")
                        
                        chunk = local_file.read(chunk_size)
                        if not chunk:
                            break
                        
                        remote_file.write(chunk)
                        bytes_transferred += len(chunk)
                        
                        if callback:
                            callback(bytes_transferred, file_size)
            
            self.logger.info(f"Uploaded {local_path} -> {normalized_path}")
        except InterruptedError:
            raise
        except Exception as e:
            raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Failed to upload file: {e}")

    def download_file(
        self,
        remote_path: str,
        local_path: str,
        callback: Optional[Callable] = None,
        check_interrupt: Optional[Callable] = None,
        offset: int = 0
    ) -> None:
        """
        Download a file from remote server with interrupt support.
        
        Args:
            remote_path: Remote file path
            local_path: Local destination path
            callback: Optional progress callback(bytes_transferred, bytes_total)
            check_interrupt: Optional function that returns True if transfer should stop
            offset: Byte offset to resume download from
        """
        if not self.is_connected():
            raise SSHFastError(ErrorCode.REMOTE_DISCONNECT, "Not connected")

        ensure_in_sandbox(remote_path, self.site_config.remote_root)
        normalized_path = normalize_remote_path(remote_path)

        try:
            # Ensure local directory exists
            fs_local_path = to_local_fs_path(local_path)
            Path(fs_local_path).parent.mkdir(parents=True, exist_ok=True)
            
            # Get remote file size
            attr = self.sftp_client.stat(normalized_path)
            file_size = attr.st_size or 0
            chunk_size = DEFAULT_STREAM_CHUNK_BYTES
            
            # Determine mode based on offset
            mode = 'wb'
            if offset > 0:
                mode = 'ab'
                
            bytes_transferred = offset
            
            with self.sftp_client.open(normalized_path, 'rb') as remote_file:
                use_readv = hasattr(remote_file, "readv") and file_size > offset
                if not use_readv:
                    if hasattr(remote_file, "prefetch"):
                        try:
                            remote_file.prefetch(file_size=file_size)
                        except TypeError:
                            remote_file.prefetch(file_size)
                        except Exception:
                            pass
                    if offset > 0:
                        remote_file.seek(offset)

                with open(fs_local_path, mode) as local_file:
                    if use_readv:
                        # readv pipelines the requests, and unlike prefetch()
                        # it fetches only [offset, file_size) on resume.
                        block_plan = []
                        position = offset
                        while position < file_size:
                            block = min(chunk_size, file_size - position)
                            block_plan.append((position, block))
                            position += block
                        for chunk in remote_file.readv(block_plan):
                            if check_interrupt and check_interrupt():
                                raise InterruptedError("Transfer interrupted")
                            if not chunk:
                                break
                            local_file.write(chunk)
                            bytes_transferred += len(chunk)
                            if callback:
                                callback(bytes_transferred, file_size)
                    else:
                        while True:
                            # Check for interruption
                            if check_interrupt and check_interrupt():
                                raise InterruptedError("Transfer interrupted")

                            chunk = remote_file.read(chunk_size)
                            if not chunk:
                                break

                            local_file.write(chunk)
                            bytes_transferred += len(chunk)

                            if callback:
                                callback(bytes_transferred, file_size)
            
            self.logger.info(f"Downloaded {normalized_path} -> {local_path}")
        except InterruptedError:
            raise
        except Exception as e:
            raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Failed to download file: {e}")

    def stat(self, remote_path: str) -> RemoteEntry:
        """
        Get file/directory attributes.
        
        Args:
            remote_path: Remote path
            
        Returns:
            RemoteEntry with file attributes
        """
        if not self.is_connected():
            raise SSHFastError(ErrorCode.REMOTE_DISCONNECT, "Not connected")

        ensure_in_sandbox(remote_path, self.site_config.remote_root)
        normalized_path = normalize_remote_path(remote_path)

        try:
            attr = self.sftp_client.stat(normalized_path)
            name = os.path.basename(normalized_path)
            return RemoteEntry(
                name=name,
                path=normalized_path,
                is_dir=(attr.st_mode & 0o170000) == 0o040000,
                size=attr.st_size or 0,
                mtime=attr.st_mtime or 0,
                mode=attr.st_mode,
            )
        except FileNotFoundError:
            raise PathNotFoundError(f"Path not found: {remote_path}")
        except Exception as e:
            raise SSHFastError(ErrorCode.UNKNOWN_ERROR, f"Failed to stat path: {e}")

    def check_path_readable(self, remote_path: str) -> bool:
        """
        Check if a remote path is readable.
        
        Args:
            remote_path: Remote path to check
            
        Returns:
            True if readable, False otherwise
        """
        try:
            self.stat(remote_path)
            return True
        except Exception:
            return False

    def check_path_writable(self, remote_path: str) -> bool:
        """
        Check if a remote path is writable by attempting to create a test file.
        
        Args:
            remote_path: Remote directory path to check
            
        Returns:
            True if writable, False otherwise
        """
        if not self.is_connected():
            return False

        try:
            test_file = f"{remote_path}/.sshfast_write_test"
            ensure_in_sandbox(test_file, self.site_config.remote_root)

            # Try to create and remove a test file
            self.sftp_client.open(test_file, 'w').close()
            self.sftp_client.remove(test_file)
            return True
        except Exception:
            return False

    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.disconnect()
