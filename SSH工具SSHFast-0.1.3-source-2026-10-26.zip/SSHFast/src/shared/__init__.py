"""Shared module initialization."""
