"""UI module initialization."""
