"""Panels module initialization."""
