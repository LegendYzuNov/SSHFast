"""Widgets module initialization."""
