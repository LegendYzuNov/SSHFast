"""Tests for the FastAPI backend health endpoint."""
from fastapi.testclient import TestClient

from backend.app.main import app


def test_health_endpoint_reports_backend_status():
    with TestClient(app) as client:
        response = client.get('/api/health')

    assert response.status_code == 200
    payload = response.json()
    assert payload['status'] in {'ok', 'degraded'}
    assert payload['service'] == 'sshfast-backend'
    assert payload['session_count'] == 0
    assert payload['auth_required'] is True
    assert payload['runtime_mode'] in {'local-dev', 'deployed-web'}
    assert payload['auth_mode'] in {'local-dev-cookie', 'cookie-session'}
    assert payload['access_cookie_name']
    assert payload['refresh_cookie_name']
    assert payload['features']
    assert 'workspace-reset' in payload['features']
    if payload['runtime_mode'] == 'local-dev':
        assert payload['auth_header_name'] == 'X-SSHFast-Token'
    if payload['ready']:
        assert payload['status'] == 'ok'
        assert payload['scheduler_running'] is True
        assert payload['startup_error'] is None
    else:
        assert payload['status'] == 'degraded'
        assert payload['scheduler_running'] is False
        assert payload['startup_error']
