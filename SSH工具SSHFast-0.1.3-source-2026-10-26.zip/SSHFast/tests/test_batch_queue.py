"""Selected transfers stay in order, including folders awaiting a scan."""

from src.core.scheduler import TaskScheduler
from src.shared.models import Task


def _task(task_id: str, *, preparing: bool = False, engine: str = "sftp") -> Task:
    return Task(
        task_id=task_id,
        kind="file_transfer",
        engine=engine,
        src=f"/local/{task_id}",
        dst=f"/remote/{task_id}",
        bytes_total=1,
        preparing=preparing,
    )


def test_fifo_batch_waits_for_folder_scan_and_ignores_protocol_round_robin(monkeypatch):
    monkeypatch.setenv("SSHFAST_MAX_WORKERS_TOTAL", "8")
    scheduler = TaskScheduler(max_workers=1, fifo_mode=True)
    try:
        assert scheduler.max_workers == 1
        scheduler.add_task(_task("first", engine="scp"))
        scheduler.add_task(_task("folder", preparing=True))
        scheduler.add_task(_task("last", engine="parallel"))

        with scheduler.task_lock:
            assert scheduler._select_next_runnable_task_locked()[0] == "first"
            assert scheduler._select_next_runnable_task_locked() is None

        assert scheduler.finish_preparing_task("folder", 2, 10)
        with scheduler.task_lock:
            assert scheduler._select_next_runnable_task_locked()[0] == "folder"
            assert scheduler._select_next_runnable_task_locked()[0] == "last"
    finally:
        scheduler.stop()


