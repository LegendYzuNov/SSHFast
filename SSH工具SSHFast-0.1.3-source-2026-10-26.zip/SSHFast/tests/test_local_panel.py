"""Smoke tests for the local file panel."""
import os

from PySide6.QtCore import QItemSelectionModel
from PySide6.QtWidgets import QApplication, QFileIconProvider

from src.ui.i18n import tr
from src.ui.panels.local_panel import LocalPanel, NameColumnDelegate


def _app() -> QApplication:
    app = QApplication.instance()
    if app is None:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        app = QApplication([])
    return app


def test_local_panel_configures_icon_provider_and_tree():
    _app()
    panel = LocalPanel()

    assert isinstance(panel.icon_provider, QFileIconProvider)
    assert panel.fs_model.iconProvider() is panel.icon_provider
    assert panel.tree.iconSize().width() == 18
    assert panel.tree.iconSize().height() == 18
    assert isinstance(panel.tree.itemDelegateForColumn(0), NameColumnDelegate)
    assert panel.fs_model.testOption(panel.fs_model.Option.DontUseCustomDirectoryIcons) is True


def test_local_panel_uploads_selected_file_and_folder(tmp_path):
    app = _app()
    (tmp_path / "one.txt").write_text("one", encoding="utf-8")
    (tmp_path / "folder").mkdir()
    panel = LocalPanel()
    panel._navigate_to(str(tmp_path))
    for _ in range(100):
        app.processEvents()
        if panel.model.rowCount(panel.tree.rootIndex()) == 2:
            break
    file_index = panel.model.index_for_path(str(tmp_path / "one.txt"))
    folder_index = panel.model.index_for_path(str(tmp_path / "folder"))
    assert file_index.isValid() and folder_index.isValid()
    for index in (file_index, folder_index):
        panel.tree.selectionModel().select(
            index, QItemSelectionModel.SelectionFlag.Select | QItemSelectionModel.SelectionFlag.Rows
        )
    emitted = []
    panel.request_upload_paths.connect(emitted.append)
    assert panel.btn_upload_selected.isEnabled()
    panel.btn_upload_selected.click()
    assert set(emitted[0]) == {str(tmp_path / "one.txt"), str(tmp_path / "folder")}


def test_local_panel_drag_animation_uses_pulse_highlight():
    _app()
    panel = LocalPanel()

    panel._start_drag_animation()

    assert panel._drag_pulse_timer.isActive() is True
    assert "border: 2px solid" in panel.tree.styleSheet()

    panel._stop_drag_animation()

    assert panel._drag_pulse_timer.isActive() is False
    assert panel.tree.styleSheet() == panel._base_tree_style


def test_local_panel_search_accepts_windows_style_patterns():
    _app()
    panel = LocalPanel()

    assert panel.path_edit.objectName() == "localPathInput"
    assert panel.search_edit.objectName() == "localSearchInput"
    assert panel.search_label.text() == tr("local.search.label")
    assert panel.search_status.text() == tr("local.search.ready")
    assert panel.btn_clear_search.isEnabled() is False
    assert panel.find_shortcut is not None
    assert panel.clear_search_shortcut is not None

    panel.search_edit.setText("*.TXT")

    assert panel.model._search_terms == ["*.txt"]
    assert panel.btn_clear_search.isEnabled() is True
    assert panel.model._search_score("Report.txt", "C:/work/Report.txt", panel.model._search_terms) == 0
    assert panel.model._search_score("notes.log", "C:/work/notes.log", panel.model._search_terms) is None

    panel.search_edit.setText(".log")

    assert panel.model._search_score("notes.LOG", "C:/work/notes.LOG", panel.model._search_terms) == 0

    panel.btn_clear_search.click()

    assert panel.search_edit.text() == ""
    assert panel.model._search_terms == []
    assert panel.search_status.text() == tr("local.search.ready")
